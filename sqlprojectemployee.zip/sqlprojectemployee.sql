CREATE DATABASE EMS_DB;
USE EMS_DB;
-- Table 1: Job Department
CREATE TABLE JobDepartment (
    Job_ID INT PRIMARY KEY,
    jobdept VARCHAR(50),
    name VARCHAR(100),
    description TEXT,
    salaryrange VARCHAR(50)
);
-- Table 2: Salary/Bonus
CREATE TABLE SalaryBonus (
    salary_ID INT PRIMARY KEY,
    Job_ID INT,
    amount DECIMAL(10,2),
    annual DECIMAL(10,2),
    bonus DECIMAL(10,2),
    CONSTRAINT fk_salary_job FOREIGN KEY (job_ID) REFERENCES JobDepartment(Job_ID)
        ON DELETE CASCADE ON UPDATE CASCADE
);
-- Table 3: Employee
CREATE TABLE Employee (
    emp_ID INT PRIMARY KEY,
    firstname VARCHAR(50),
    lastname VARCHAR(50),
    gender VARCHAR(10),
    age INT,
    contact_add VARCHAR(100),
    emp_email VARCHAR(100) UNIQUE,
    emp_pass VARCHAR(50),
    Job_ID INT,
    CONSTRAINT fk_employee_job FOREIGN KEY (Job_ID)
        REFERENCES JobDepartment(Job_ID)
        ON DELETE SET NULL
        ON UPDATE CASCADE
);

-- Table 4: Qualification
CREATE TABLE Qualification (
    QualID INT PRIMARY KEY,
    Emp_ID INT,
    Position VARCHAR(50),
    Requirements VARCHAR(255),
    Date_In DATE,
    CONSTRAINT fk_qualification_emp FOREIGN KEY (Emp_ID)
        REFERENCES Employee(emp_ID)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);

-- Table 5: Leaves
CREATE TABLE Leaves (
    leave_ID INT PRIMARY KEY,
    emp_ID INT,
    date DATE,
    reason TEXT,
    CONSTRAINT fk_leave_emp FOREIGN KEY (emp_ID) REFERENCES Employee(emp_ID)
        ON DELETE CASCADE ON UPDATE CASCADE
);

-- Table 6: Payroll
CREATE TABLE Payroll (
    payroll_ID INT PRIMARY KEY,
    emp_ID INT,
    job_ID INT,
    salary_ID INT,
    leave_ID INT,
    date DATE,
    report TEXT,
    total_amount DECIMAL(10,2),
    CONSTRAINT fk_payroll_emp FOREIGN KEY (emp_ID) REFERENCES Employee(emp_ID)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_payroll_job FOREIGN KEY (job_ID) REFERENCES JobDepartment(job_ID)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_payroll_salary FOREIGN KEY (salary_ID) REFERENCES SalaryBonus(salary_ID)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_payroll_leave FOREIGN KEY (leave_ID) REFERENCES Leaves(leave_ID)
        ON DELETE SET NULL ON UPDATE CASCADE
);
SELECT * FROM  JobDepartment;
SELECT * FROM  SalaryBonus;
SELECT * FROM Employee;
SELECT * FROM QUALIFICATION;
SELECT * FROM Leaves;
SELECT * FROM Payroll;
-- 1. EMPLOYEE INSIGHTS
-- How many unique employees are currently in the system?
SELECT COUNT(*) AS Total_Employees
FROM Employee;

-- Which departments have the highest number of employees?
SELECT jd.jobdept, COUNT(e.emp_ID) AS Employee_Count
FROM Employee e
JOIN JobDepartment jd
ON e.Job_ID = jd.Job_ID
GROUP BY jd.jobdept
ORDER BY Employee_Count DESC;

-- What is the average salary per department?
SELECT jd.jobdept,
       AVG(sb.amount) AS Avg_Salary
FROM JobDepartment jd
JOIN SalaryBonus sb
ON jd.Job_ID = sb.Job_ID
GROUP BY jd.jobdept;

-- Who are the top 5 highest-paid employees?
SELECT e.emp_ID,
       e.firstname,
       e.lastname,
       sb.amount AS Salary
FROM Employee e
JOIN SalaryBonus sb
ON e.Job_ID = sb.Job_ID
ORDER BY sb.amount DESC
LIMIT 5;

-- What is the total salary expenditure across the company?
SELECT SUM(total_amount) AS Total_Salary_Expenditure
FROM Payroll;
-- 2. JOB ROLE AND DEPARTMENT ANALYSIS
-- How many different job roles exist in each department?
SELECT jobdept,
       COUNT(Job_ID) AS Total_Job_Roles
FROM JobDepartment
GROUP BY jobdept;

-- What is the average salary range per department?
SELECT
    J.jobdept,
    ROUND(AVG(S.amount),2) AS avg_salary
FROM JobDepartment J
JOIN SalaryBonus S
ON J.Job_ID = S.Job_ID
GROUP BY J.jobdept
ORDER BY avg_salary DESC;


-- Which job roles offer the highest salary?
SELECT jd.name AS Job_Role,
       sb.amount
FROM JobDepartment jd
JOIN SalaryBonus sb
ON jd.Job_ID = sb.Job_ID
ORDER BY sb.amount DESC
LIMIT 1;

-- Which departments have the highest total salary allocation?
SELECT jd.jobdept,
       SUM(sb.annual) AS Total_Salary_Allocation
FROM JobDepartment jd
JOIN SalaryBonus sb
ON jd.Job_ID = sb.Job_ID
GROUP BY jd.jobdept
ORDER BY Total_Salary_Allocation DESC;

-- 3. QUALIFICATION AND SKILLS ANALYSIS
-- How many employees have at least one qualification listed?
SELECT COUNT(DISTINCT Emp_ID) AS Qualified_Employees
FROM Qualification;

-- Which positions require the most qualifications?
SELECT Position,
       COUNT(*) AS Qualification_Count
FROM Qualification
GROUP BY Position
ORDER BY Qualification_Count DESC;

-- Which employees have the highest number of qualifications?
SELECT e.emp_ID,
       e.firstname,
       e.lastname,
       COUNT(q.QualID) AS Qualification_Count
FROM Employee e
JOIN Qualification q
ON e.emp_ID = q.Emp_ID
GROUP BY e.emp_ID, e.firstname, e.lastname
ORDER BY Qualification_Count DESC;

-- 4. LEAVE AND ABSENCE PATTERNS
-- Which year had the most employees taking leaves?
SELECT YEAR(date) AS Leave_Year,
       COUNT(DISTINCT emp_ID) AS Employees_On_Leave
FROM Leaves
GROUP BY YEAR(date)
ORDER BY Employees_On_Leave DESC;

-- What is the average number of leave days taken by its employees per department?
SELECT jd.jobdept,
       AVG(Leave_Count) AS Avg_Leave_Days
FROM (
      SELECT emp_ID,
             COUNT(*) AS Leave_Count
      FROM Leaves
      GROUP BY emp_ID
     ) l
JOIN Employee e
ON l.emp_ID = e.emp_ID
JOIN JobDepartment jd
ON e.Job_ID = jd.Job_ID
GROUP BY jd.jobdept;

-- Which employees have taken the most leaves?
SELECT e.emp_ID,
       e.firstname,
       e.lastname,
       COUNT(l.leave_ID) AS Total_Leaves
FROM Employee e
JOIN Leaves l
ON e.emp_ID = l.emp_ID
GROUP BY e.emp_ID, e.firstname, e.lastname
ORDER BY Total_Leaves DESC;

-- What is the total number of leave days taken company-wide?
SELECT COUNT(*) AS Total_Leave_Days
FROM Leaves;

-- How do leave days correlate with payroll amounts?
SELECT e.emp_ID,
       e.firstname,
       COUNT(l.leave_ID) AS Leave_Days,
       AVG(p.total_amount) AS Avg_Payroll
FROM Employee e
LEFT JOIN Leaves l
ON e.emp_ID = l.emp_ID
LEFT JOIN Payroll p
ON e.emp_ID = p.emp_ID
GROUP BY e.emp_ID, e.firstname
ORDER BY Leave_Days DESC;

-- 5. PAYROLL AND COMPENSATION ANALYSIS
-- What is the total monthly payroll processed?
SELECT YEAR(date) AS Year,
       MONTH(date) AS Month,
       SUM(total_amount) AS Monthly_Payroll
FROM Payroll
GROUP BY YEAR(date), MONTH(date)
ORDER BY Year, Month;

-- What is the average bonus given per department?
SELECT jd.jobdept,
       AVG(sb.bonus) AS Avg_Bonus
FROM JobDepartment jd
JOIN SalaryBonus sb
ON jd.Job_ID = sb.Job_ID
GROUP BY jd.jobdept;

-- Which department receives the highest total bonuses?
SELECT jd.jobdept,
       SUM(sb.bonus) AS Total_Bonus
FROM JobDepartment jd
JOIN SalaryBonus sb
ON jd.Job_ID = sb.Job_ID
GROUP BY jd.jobdept
ORDER BY Total_Bonus DESC;

-- What is the average value of total_amount after considering leave deductions?
SELECT AVG(total_amount) AS Avg_Final_Payroll
FROM Payroll;

